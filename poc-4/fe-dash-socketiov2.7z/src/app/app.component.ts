import { Component, OnInit } from '@angular/core';
import io from 'socket.io-client';

const socket = io('http://localhost:3000');

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'dashboard';
  chart;
  chart2 = [];
  pie: any;
  doughnut: any;

  data1 = [];

  ngOnInit() {

    socket.on('data1', (res) => {
      console.log("RES 1: ", res)
    })

    socket.on('data2', (res) => {
      console.log("RES 2: ", res)
    })
  }

}
