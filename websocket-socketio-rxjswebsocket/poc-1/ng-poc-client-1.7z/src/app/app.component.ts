import { Component } from '@angular/core';
import { Observable, Subject, EMPTY, of, interval } from "rxjs";
import { webSocket, WebSocketSubject } from "rxjs/webSocket";


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'rt-client';
  myws: WebSocketSubject<any> = webSocket("wss://echo.websocket.org");
  //myws: WebSocketSubject<any> = webSocket("ws://localhost:3000");

  ngOnInit() {
    this.myws
      .asObservable()
      .subscribe(dataFromServer => console.log("Data:", dataFromServer));

    setInterval(() => {
      this.myws.next({ message: this.getRandMessage() });
    }, 5000);
  }

  getRandMessage() {
    return "Pippo_" + Math.random();
  }
}
