This folder contains the code to create a real time application with React, Angular and socket.io with NodeJS.
Angular version is 8 and node is built with express framework.
To read about the article you can follow the article link at my website.

React:
https://deepinder.me/creating-a-real-time-chat-application-with-angular-and-socket-io-with-nodejs/

Angular:
https://deepinder.me/creating-a-real-time-app-with-angular-8-and-socket-io-with-nodejs/